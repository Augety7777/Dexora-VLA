"""
Load and save from ACT Raw format and BSON format
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from copy import deepcopy
from os import makedirs
from pathlib import Path
from typing import Dict, List, Optional, Union

import bson
import cv2

from .schemas import validate
from .utils import encode_h264


def load_bson(bson_path: Path) -> dict:
    with open(bson_path, "rb") as f:
        data = bson.decode(f.read())
    return validate(data)


def save_bson(sample: dict, bson_path: Path):
    validate(sample)
    sample = deepcopy(sample)
    for topic, topic_data in sample['data'].items():
        if sample['metadata']['topics'][topic]['type'] == 'image':
            sample['data'][topic] = encode_h264(topic_data)

    makedirs(bson_path.parent, exist_ok=True)
    with open(bson_path, "wb") as f:
        f.write(bson.encode(sample))


def load_actraw(load_path: Path, meta_override: dict | None = None) -> dict:
    with open(load_path / "low_dim.json", encoding='utf8') as f:
        low_dim_data = json.load(f)
        low_dim_topics = low_dim_data.keys()

    def is_jointarray(topic_name: str) -> bool:
        return len(low_dim_data[topic_name][0]) == 6

    with open(load_path / "timestamps.json", encoding='utf8') as f:
        timestamps = json.load(f)
        image_cams = list(timestamps['images'].keys())

    # Note: by default the metadata of jointstate is fake
    jointstate_meta_default = {
        "description": "airbot-play-short",
        "type": "jointstate",
        "sn": "PZ25C0240100048X",
        "firmware_version": "3.1.5"
    }

    # Note: by default the metadata of image is fake
    image_meta_default = {
        "description": "DSJ-2062-309",
        "type": "image",
        "width": 640,
        "height": 480,
        "encoding": "H264",
        "distortion_model": None,
        "distortion_params": None,
        "intrinsics": None,
        "fov": 120.
    }

    metadata = {
        "version": "1.2.2",
        "operator": "Hongrui",
        "task": "place-cup-on-fixed-plate",
        "station_id": "3784D4BA-87AF-47E7-B86D-42CA1904AA77",
        "driver_version": "3.1.5",
        "topics": {
            **{
                f'/{k}': jointstate_meta_default for k in low_dim_topics
            },
            **{
                f'/images/{k}': image_meta_default for k in image_cams
            }
        }
    }

    if meta_override is not None:
        metadata.update(meta_override)

    # NOTE: This is under the assumption that the float array represents positions
    def handle_jointstate(topic: str) -> list:
        return [{
            't': int(t * 1e3),
            'data': {
                "pos": v,
                "vel": None,
                "eff": None
            }
        } for t, v in zip(timestamps['low_dim'], low_dim_data[topic])]

    def handle_pose(topic: str) -> list:
        return [{
            't': int(t * 1e3),
            'data': {
                't': v[:3],
                'r': v[3:],
            }
        } for t, v in zip(timestamps['low_dim'], low_dim_data[topic])]

    def handle_image(cam_name: str) -> list:
        cap = cv2.VideoCapture(f'{load_path}/observation.images.{cam_name}.mp4')
        frames = []
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frames.append(frame)
        cap.release()

        start_time = timestamps['images'][cam_name][0]

        metadata['topics'][f'/images/{cam_name}']['start_time'] = int(
            start_time * 1e3)
        return [{
            't': int(t * 1e3),
            'data': frame
        } for t, frame in zip(timestamps['images'][cam_name], frames)]

    datapts = {
        **{
            f'/{k}': handle_jointstate(k) for k in low_dim_topics if is_jointarray(k)
        },
        **{
            f'/{k}': handle_pose(k) for k in low_dim_topics if not is_jointarray(k)
        },
        **{
            f'/images/{k}': handle_image(k) for k in image_cams
        }
    }

    episode = {
        "id": str(uuid.uuid4()),
        "timestamp": time.time_ns(),
        "metadata": metadata,
        "data": datapts
    }
    return validate(episode)


def save_actraw(sample: dict, save_path: Path) -> None:
    validate(sample)
    makedirs(save_path, exist_ok=True)

    image_topics_names = [
        k for k, v in sample['metadata']['topics'].items()
        if v['type'] == 'image'
    ]

    # NOTE: This is under the assumption that cam name is the second last when the image topic name is split by '/'
    def get_cam_name(i: str) -> str:
        return i.split('/')[-1]

    jointstate_topics_names = [
        k for k, v in sample['metadata']['topics'].items()
        if v['type'] in ['jointstate', 'pose']
    ]

    # meta.json
    lengths = [len(v) for v in sample['data'].values()]
    target_length = lengths[0]
    if not all(l == target_length for l in lengths):
        logging.warning("Data lengths are not equal")

    fps = 1000 / (sample['data'][image_topics_names[0]][1]['t'] -
                  sample['data'][image_topics_names[0]][0]['t'])

    with open(save_path / 'meta.json', 'w', encoding="utf8") as f:
        json.dump({'length': target_length, 'fps': int(fps)}, f, indent=4)

    # low_dim.json
    with open(save_path / 'low_dim.json', 'w', encoding='utf8') as f:
        json.dump(
            {
                key: [v['data'] for v in sample['data'][key]]
                for key in jointstate_topics_names
            },
            f,
            indent=4)

    # timestamps.json
    with open(save_path / 'timestamps.json', 'w', encoding="utf8") as f:
        json.dump(
            {
                "low_dim": [
                    float(v['t']) / 1e3
                    for v in sample['data'][jointstate_topics_names[0]]
                ],
                "images": {
                    get_cam_name(im_topic):
                        [float(v['t']) / 1e3 for v in sample['data'][im_topic]]
                    for im_topic in image_topics_names
                },
            },
            f,
            indent=4)

    # observation.images.*.mp4
    for im_topic in image_topics_names:
        stream = encode_h264(sample['data'][im_topic])
        with open(
                save_path / f"observation.images.{get_cam_name(im_topic)}.mp4",
                'wb',
        ) as f:
            f.write(stream)


def save_json_debug(sample: dict, save_path: Path) -> None:
    validate(sample)
    makedirs(save_path.parent, exist_ok=True)

    for image_topic in sample['metadata']['topics']:
        sample['data'][image_topic] = sample['data'][image_topic][:1]
        if sample['metadata']['topics'][image_topic]['type'] == 'image':
            for i in range(len(sample['data'][image_topic])):
                sample['data'][image_topic][i]['data'] = "np.ndarray"

    with open(save_path, 'w', encoding="utf8") as f:
        json.dump(sample, f, indent='\t')
