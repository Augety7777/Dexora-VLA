"""
Defines the basic structure and deserializer
"""
from __future__ import annotations

import uuid
from typing import List

import numpy as np
from schema import And, Or, Regex, Schema, Use

from .utils import decode_h264, decode_jpeg


class SCHEMAV120:
    """
    Schema definition version 1.2.2
    """
    VERSION = "1.2.2"

    @staticmethod
    def valid_topic_type(t: str):
        return t in ["image", "jointstate"]

    @staticmethod
    def valid_encoding(t: str):
        return t in ["JPEG", "H264"]

    @staticmethod
    def valid_uuid(test_str: str) -> bool:
        try:
            uuid.UUID(test_str)
            return True
        except ValueError:
            return False

    DPT_POSE_META = Schema({
        "description": str,
        "type": "pose",
    })

    DPT_POSE = Schema({
        "t": int,
        "data": {
            "t": [float],
            "r": [float],
        },
    })

    # "t" is timestamp in milliseconds
    # "data" is a bytearray of jpeg (or other codec, as specified in the meta info) encoded frame
    DPT_IMAGE_FRAME = Schema({
        "t":
            int,
        "data":
            Or(
                np.ndarray,
                Use(decode_jpeg,
                    error="Fail to decode JPEG in image data point"))
    })

    DPT_IMAGE_META = Schema({
        "description": str,
        "type": "image",
        "width": int,
        "height": int,
        "encoding": str,
        "distortion_model": Or(str, None),
        "distortion_params": Or(And([float], lambda x: len(x) == 5), None),
        "intrinsics": Or(And([float], lambda x: len(x) == 4), None),
        "fov": float,
        "start_time": int,
    })

    # "data" is a bytearray of h264 (or other codec, as specified in the meta info) encoded video frames
    # Timestamps are in milliseconds; already integrated in the bytearray
    DPT_IMAGE_VIDEO = Schema(
        Or(
            [{
                "t": int,
                "data": np.ndarray,
            }],
            Use(decode_h264),
        ))
    DPT_JOINTSTATES_META = Schema({
        "description": str,
        "type": "jointstate",
        "sn": str,
        "firmware_version": Regex(r'^\d+\.\d+\.\d+$'),
    })

    @staticmethod
    def valid_jointstate_data(data: dict) -> bool:
        # Check if all values are None
        if all(value is None for value in data['data'].values()):
            return False

        # Filter out None values
        non_none_values = [
            value for value in data['data'].values() if value is not None
        ]

        # Check if the lengths of non-None values are the same
        if len({len(value) for value in non_none_values}) != 1:
            return False

        return True

    DPT_JOINTSTATES = Schema(
        And(
            {
                "t": int,
                "data": {
                    "pos": Or([float], None),
                    "vel": Or([float], None),
                    "eff": Or([float], None),
                },
            }, Use(valid_jointstate_data)))
    SAMPLE = Schema(
        And(
            {
                "id": And(str, valid_uuid),
                "timestamp": int,
                "metadata": {
                    "version": VERSION,
                    "operator": Or(str, None),
                    "task": str,
                    "station_id": And(str, valid_uuid),
                    "driver_version": Regex(r'^\d+\.\d+\.\d+$'),
                    "topics": {
                        str:
                            Or(DPT_IMAGE_META, DPT_JOINTSTATES_META,
                               DPT_POSE_META)
                    },
                },
                "data": {
                    str:
                        Or(
                            DPT_IMAGE_VIDEO, [Or(
                                DPT_JOINTSTATES,
                                DPT_POSE,
                                DPT_IMAGE_FRAME,
                            )],),
                }
            },
            lambda x: set(x['metadata']['topics'].keys()) == set(x['data'].keys(
            ))))


SCHEMA = SCHEMAV120


def validate(sample: dict) -> dict:
    return SCHEMA.SAMPLE.validate(sample)

