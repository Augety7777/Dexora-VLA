#   -------------------------------------------------------------
#   Copyright (c) Microsoft Corporation. All rights reserved.
#   Licensed under the MIT License. See LICENSE in project root for information.
#   -------------------------------------------------------------
"""Handler and utilities for AIRBOT datasets, samples and annotations."""
from __future__ import annotations

__version__ = "1.2.1"
